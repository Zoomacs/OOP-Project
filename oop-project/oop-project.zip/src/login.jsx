import "./login.css";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { apiFetch } from "./api";

function Login({ page }) {
  useEffect(() => { page("login"); }, [page]);

  const [ID, setID]           = useState("");
  const [password, setPassword] = useState("");
  const [error, setError]     = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    const id  = ID.trim();
    const pwd = password.trim();
    if (!id || !pwd) { setError("Please fill in both fields."); return; }

    setLoading(true);
    try {
      const data = await apiFetch("api.php?route=login", {
        method: "POST",
        body: JSON.stringify({ id, password: pwd }),
      });

      // Persist everything React pages need
      sessionStorage.setItem("userRole",       data.role);
      sessionStorage.setItem("userId",         String(data.user_id));
      sessionStorage.setItem("userName",       data.name);
      sessionStorage.setItem("customerId",     String(data.customer_id  ?? ""));
      sessionStorage.setItem("restaurantId",   String(data.restaurant_id ?? ""));

      if      (data.role === "admin")  navigate("/admin",           { replace: true });
      else if (data.role === "owner")  navigate("/owner/dashboard", { replace: true });
      else if (data.role === "staff")  navigate("/staff/orders",    { replace: true });
      else                             navigate("/home",             { replace: true });

    } catch (err) {
      setError(err.message || "Invalid ID or password.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="qless-wrapper">
      <div className="qless-left">
        <div>
          <span className="qless-logo-text">Q-Less</span>
          <p className="qless-welcome">Welcome back, Academic</p>
        </div>

        <div className="qless-form">
          <div className="qless-field-group">
            <label className="qless-label">ID</label>
            <div className="qless-input-wrapper">
              <input
                type="text"
                placeholder="Your university ID"
                value={ID}
                onChange={(e) => setID(e.target.value)}
                className="qless-input"
              />
            </div>
          </div>

          <div className="qless-field-group">
            <div className="qless-password-header">
              <label className="qless-label">Password</label>
              <a href="#" className="qless-forgot-password">Forgot Password?</a>
            </div>
            <div className="qless-input-wrapper">
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="qless-input"
              />
            </div>
          </div>

          {error && (
            <p style={{ color: "#c0392b", fontSize: "0.85rem", margin: "4px 0" }}>
              {error}
            </p>
          )}

          <button onClick={handleSubmit} className="qless-sign-in-button" disabled={loading}>
            {loading ? "Signing in…" : "Sign In"}
          </button>

          <div className="qless-divider"></div>

          <div className="qless-sign-up">
            <p className="qless-sign-up-text">New to campus dining?</p>
            <button className="qless-sign-up-button" onClick={() => navigate("/register")}>
              Register Account
            </button>
          </div>
        </div>

        <div className="qless-footer">
          <span>© 2026 Q-LESS UNIVERSITY</span>
          <a href="#">Privacy</a>
          <a href="#">Terms</a>
        </div>
      </div>

      <div className="qless-right-side">
        <div className="qless-badge">CAMPUS NEWS</div>
        <p className="qless-tagline">Skip the line,<br /> stay in the <span>flow</span>.</p>
        <div className="qless-big-title">
          <span className="qless-big-word">CAMPUS</span><br />
          <span className="qless-big-word-alt">LIFE</span>
        </div>
        <div className="qless-social-proof">
          <p className="qless-social-bold">Join 2,400+ students</p>
          <p className="qless-social-sub">ordering lunch right now at Central Hall.</p>
        </div>
      </div>
    </div>
  );
}

export default Login;
