import "./Contact.css";
import "./main.css";
import { useEffect, useState, useRef } from "react";
import AdminReturnButton from "./AdminReturnButton";
import { BACKEND } from "./api";

function Contact({ page }) {
  useEffect(() => {
    page("contact");
  }, [page]);

  const titleRef   = useRef(null);
  const messageRef = useRef(null);
  const [status, setStatus]   = useState(""); // "", "sending", "ok", "error"
  const [errMsg, setErrMsg]   = useState("");

  const handleSubmit = async () => {
    const title   = titleRef.current?.value.trim()   ?? "";
    const message = messageRef.current?.value.trim() ?? "";

    if (!title || !message) {
      setErrMsg("Please fill in both title and description.");
      setStatus("error");
      return;
    }

    setStatus("sending");
    setErrMsg("");

    try {
      const user_id    = sessionStorage.getItem("userId")    || null;
      const user_email = sessionStorage.getItem("userEmail") || "";

      const res = await fetch(`${BACKEND}/tickets.php`, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_id, user_email, title, message }),
      });

      const data = await res.json();

      if (data.success) {
        setStatus("ok");
        if (titleRef.current)   titleRef.current.value   = "";
        if (messageRef.current) messageRef.current.value = "";
      } else {
        setErrMsg(data.message || "Failed to send ticket.");
        setStatus("error");
      }
    } catch {
      setErrMsg("Network error — is XAMPP running?");
      setStatus("error");
    }
  };

  return (
    <>
      <title>Contact</title>
      <div className="contact-container">
        <div className="contact-left">
          <div className="support-badge">Support Center</div>
          <h1 className="main-heading">
            How can we <span className="highlight">help you</span> today?
          </h1>
          <p className="support-description">
            Our dedicated team is ready to ensure your campus dining experience
            is seamless. From order inquiries to technical support, we're here
            for you.
          </p>
          <div className="action-buttons">
            <button className="view-tickets">View Tickets</button>
          </div>
        </div>
        <div className="contact-right">
          <div className="contact-card">
            <h1 id="contact">Contact Us</h1>
            <div className="form-row">
              <label htmlFor="title"></label>
              <input id="title" ref={titleRef} placeholder="Title" />
            </div>
            <div className="form-row">
              <label></label>
              <textarea id="message" ref={messageRef} placeholder="Description"></textarea>
            </div>

            {status === "ok" && (
              <p style={{ color: "#27ae60", marginBottom: "8px" }}>
                ✓ Your message was sent successfully!
              </p>
            )}
            {status === "error" && (
              <p style={{ color: "#c0392b", marginBottom: "8px" }}>{errMsg}</p>
            )}

            <div
              className="submit"
              onClick={handleSubmit}
              style={{ cursor: status === "sending" ? "wait" : "pointer", opacity: status === "sending" ? 0.7 : 1 }}
            >
              {status === "sending" ? "Sending…" : "Send Message"}
            </div>
          </div>
        </div>
      </div>
      <AdminReturnButton />
    </>
  );
}
export default Contact;
