import { useEffect, useState } from "react";
import { Card, StatCard, Badge } from "../components/UI";
import { BACKEND } from "../../api";
import "./Dashboard.css";

export default function Dashboard() {
  const [stats, setStats]       = useState(null);
  const [activity, setActivity] = useState([]);
  const [loading, setLoading]   = useState(true);

  useEffect(() => {
    fetch(`${BACKEND}/api.php?route=admin-analytics`)
      .then((r) => r.json())
      .then((data) => {
        setStats(data.stats ?? {});
        setActivity(data.recent_activity ?? []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  return (
    <>
      <section className="hero">
        <h1>Admin Control Center</h1>
        <p className="subtitle">
          Powerful Q-Less restaurant dashboard for users, restaurants, orders, payments and support.
        </p>
      </section>

      {loading ? (
        <p style={{ padding: "20px" }}>Loading stats…</p>
      ) : (
        <div className="grid">
          <StatCard title="Total Users"         value={stats?.total_users        ?? "—"} badge="+live"      type="green" />
          <StatCard title="Active Restaurants"  value={stats?.active_restaurants ?? "—"} badge="Live"       badgeClass="gold" />
          <StatCard title="Orders Today"        value={stats?.orders_today       ?? "—"} badge="Tracking"   badgeClass="blue" />
          <StatCard title="Open Tickets"        value={stats?.open_tickets       ?? "—"} badge="Need reply" badgeClass="red" />
        </div>
      )}

      <div style={{ marginTop: 20 }}>
        <Card className="table-wrap">
          <h3>Recent Activity</h3>
          <table>
            <thead>
              <tr><th>Action</th><th>User</th><th>Status</th></tr>
            </thead>
            <tbody>
              {activity.length === 0 && !loading && (
                <tr><td colSpan={3} style={{ textAlign: "center", color: "#888" }}>No recent activity.</td></tr>
              )}
              {activity.map((row, i) => (
                <tr key={i}>
                  <td>{row.action}</td>
                  <td>{row.user}</td>
                  <td><Badge type="green">{row.status}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>
    </>
  );
}
