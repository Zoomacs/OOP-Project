import { useEffect, useState } from "react";
import { PageHeader, Card, Badge } from "../components/UI";
import { BACKEND } from "../../api";
import "./ViewCustomers.css";

export default function ViewCustomers() {
  const [users, setUsers]     = useState([]);
  const [search, setSearch]   = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`${BACKEND}/api.php?route=admin-users&role=student`)
      .then((r) => r.json())
      .then((data) => { setUsers(Array.isArray(data) ? data : []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const filtered = users.filter((u) =>
    `${u.full_name} ${u.email}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <>
      <PageHeader title="View Customers" subtitle="Customer list and activity.">
        <input
          className="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search customers..."
        />
      </PageHeader>

      {loading && <p style={{ padding: "20px" }}>Loading customers…</p>}

      <Card className="table-wrap">
        <table>
          <thead>
            <tr><th>Customer</th><th>Email</th><th>Orders</th><th>Spent</th><th>Status</th></tr>
          </thead>
          <tbody>
            {!loading && filtered.length === 0 && (
              <tr><td colSpan={5} style={{ textAlign: "center", color: "#888" }}>No customers found.</td></tr>
            )}
            {filtered.map((user) => (
              <tr key={user.user_id}>
                <td>{user.full_name}</td>
                <td>{user.email}</td>
                <td>{user.order_count ?? 0}</td>
                <td>{user.total_spent ?? 0} EGP</td>
                <td>
                  <Badge type={user.status === "banned" ? "red" : "green"} style={{ textTransform: "capitalize" }}>
                    {user.status}
                  </Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </>
  );
}
