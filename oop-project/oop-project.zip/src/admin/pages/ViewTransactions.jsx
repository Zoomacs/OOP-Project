import { useEffect, useState } from "react";
import { PageHeader, Card, Badge } from "../components/UI";
import { BACKEND } from "../../api";
import "./ViewTransactions.css";

export default function ViewTransactions() {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading]           = useState(true);

  useEffect(() => {
    // Uses the admin-orders route; payments are joined server-side
    // If a dedicated payments route exists later, swap the URL here
    fetch(`${BACKEND}/api.php?route=admin-orders`)
      .then((r) => r.json())
      .then((data) => {
        // Flatten: each order may carry payment info when the backend joins it
        const rows = Array.isArray(data) ? data : [];
        setTransactions(rows);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const badgeType = (status) => {
    if (!status) return "gold";
    const s = status.toLowerCase();
    if (s === "approved" || s === "paid") return "green";
    if (s === "rejected" || s === "failed") return "red";
    return "gold";
  };

  return (
    <>
      <PageHeader title="View Transactions" subtitle="All customer and restaurant payment transactions." />

      {loading && <p style={{ padding: "20px" }}>Loading transactions…</p>}

      <Card className="table-wrap">
        <table>
          <thead>
            <tr><th>Order ID</th><th>Date</th><th>Customer</th><th>Restaurant</th><th>Amount</th><th>Status</th></tr>
          </thead>
          <tbody>
            {!loading && transactions.length === 0 && (
              <tr><td colSpan={6} style={{ textAlign: "center", color: "#888" }}>No transactions yet.</td></tr>
            )}
            {transactions.map((trx) => (
              <tr key={trx.order_id}>
                <td>#{trx.order_id}</td>
                <td>{trx.created_at ? new Date(trx.created_at).toLocaleDateString() : "—"}</td>
                <td>{trx.customer_name   ?? "—"}</td>
                <td>{trx.restaurant_name ?? "—"}</td>
                <td>{trx.total_price} EGP</td>
                <td>
                  <Badge type={badgeType(trx.payment_status)} style={{ textTransform: "capitalize" }}>
                    {trx.payment_status ?? trx.status ?? "pending"}
                  </Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </>
  );
}
