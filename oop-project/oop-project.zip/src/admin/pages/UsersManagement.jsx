import { useEffect, useState } from "react";
import { PageHeader, Card, Badge, notify } from "../components/UI";
import { BACKEND } from "../../api";
import "./UsersManagement.css";

export default function UsersManagement() {
  const [users, setUsers]     = useState([]);
  const [search, setSearch]   = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`${BACKEND}/api.php?route=admin-users`)
      .then((r) => r.json())
      .then((data) => { setUsers(Array.isArray(data) ? data : []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const toggleBan = async (user) => {
    const newStatus = user.status === "banned" ? "active" : "banned";
    try {
      await fetch(`${BACKEND}/api.php?route=admin-users`, {
        method:  "PUT",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ id: user.user_id, status: newStatus }),
      });
      setUsers((prev) =>
        prev.map((u) => u.user_id === user.user_id ? { ...u, status: newStatus } : u)
      );
      notify(`${user.full_name} ${newStatus === "banned" ? "banned" : "unbanned"}`);
    } catch {
      notify("Action failed — check network.");
    }
  };

  const filtered = users.filter((u) =>
    `${u.full_name} ${u.email} ${u.role} ${u.status}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  return (
    <>
      <PageHeader title="Users Management" subtitle="View, search, ban, and manage users.">
        <input
          className="search"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search users..."
        />
      </PageHeader>

      {loading && <p style={{ padding: "20px" }}>Loading users…</p>}

      <Card className="table-wrap">
        <table>
          <thead>
            <tr><th>Name</th><th>Email</th><th>Type</th><th>Status</th><th>Action</th></tr>
          </thead>
          <tbody>
            {!loading && filtered.length === 0 && (
              <tr><td colSpan={5} style={{ textAlign: "center", color: "#888" }}>No users found.</td></tr>
            )}
            {filtered.map((user) => (
              <tr key={user.user_id}>
                <td>{user.full_name}</td>
                <td>{user.email}</td>
                <td style={{ textTransform: "capitalize" }}>{user.role}</td>
                <td>
                  <Badge type={user.status === "banned" ? "red" : "green"} style={{ textTransform: "capitalize" }}>
                    {user.status}
                  </Badge>
                </td>
                <td>
                  <button
                    className={`btn ${user.status === "banned" ? "" : "red"}`}
                    onClick={() => toggleBan(user)}
                  >
                    {user.status === "banned" ? "Unban" : "Ban"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </>
  );
}
