import { useState } from "react";
import logo from "../../assets/q-less-logo.png";
import "./AdminLogin.css";
import { BACKEND } from "../../api";

export default function AdminLogin({ onLogin }) {
  const [adminId, setAdminId]   = useState("");
  const [password, setPassword] = useState("");
  const [error, setError]       = useState("");
  const [loading, setLoading]   = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const id  = adminId.trim();
    const pwd = password.trim();

    if (!id || !pwd) {
      setError("Please fill in both fields.");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const res  = await fetch(`${BACKEND}/api.php?route=login`, {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ id, password: pwd }),
      });
      const data = await res.json();

      if (data.success && data.role === "admin") {
        // Persist session info so other admin pages can read it
        sessionStorage.setItem("userRole", data.role);
        sessionStorage.setItem("userId",   String(data.user_id));
        sessionStorage.setItem("userName", data.name);
        onLogin();
      } else if (data.success) {
        setError("This account does not have admin privileges.");
      } else {
        setError(data.message || "Wrong admin ID or password.");
      }
    } catch {
      setError("Network error — is XAMPP running?");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="admin-login-page">
      <form className="admin-login-card" onSubmit={handleSubmit}>
        <img src={logo} alt="Q-Less logo" className="admin-login-logo" />
        <h1>Admin Login</h1>
        <p>Use the admin account to access the dashboard.</p>

        <label>Admin ID</label>
        <input
          value={adminId}
          onChange={(e) => setAdminId(e.target.value)}
          placeholder="admin"
          autoComplete="username"
        />

        <label>Password</label>
        <input
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="••••••••"
          type="password"
          autoComplete="current-password"
        />

        {error && <span className="admin-login-error">{error}</span>}

        <button type="submit" disabled={loading}>
          {loading ? "Logging in…" : "Login"}
        </button>

        <div className="admin-login-hint">
          ID: <b>admin</b> &nbsp; Password: <b>admin123</b>
        </div>
      </form>
    </div>
  );
}
