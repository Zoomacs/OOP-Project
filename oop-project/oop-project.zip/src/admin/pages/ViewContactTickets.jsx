import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { PageHeader, Card } from "../components/UI";
import { BACKEND } from "../../api";
import "./ViewContactTickets.css";

export default function ViewContactTickets() {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetch(`${BACKEND}/api.php?route=tickets`)
      .then((r) => r.json())
      .then((data) => { setTickets(Array.isArray(data) ? data : []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  return (
    <>
      <PageHeader title="View Contact Tickets" subtitle="Read customer contact messages." />

      {loading && <p style={{ padding: "20px" }}>Loading tickets…</p>}

      <Card>
        {!loading && tickets.length === 0 && (
          <p style={{ padding: "12px", color: "#888" }}>No tickets yet.</p>
        )}
        {tickets.map((ticket) => (
          <div className="ticket" key={ticket.ticket_id}>
            <div>
              <b>#{ticket.ticket_id} — {ticket.title}</b>
              <p className="muted">From: {ticket.user_email || "Guest"}</p>
            </div>
            <button
              className="btn dark"
              onClick={() =>
                navigate("/admin/reply-contact-ticket", { state: { ticket } })
              }
            >
              View
            </button>
          </div>
        ))}
      </Card>
    </>
  );
}
