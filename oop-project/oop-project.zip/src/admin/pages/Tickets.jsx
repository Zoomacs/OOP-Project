import { useEffect, useState } from "react";
import { PageHeader, Card, Badge } from "../components/UI";
import { BACKEND } from "../../api";
import "./Tickets.css";

export default function Tickets() {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`${BACKEND}/api.php?route=tickets`)
      .then((r) => r.json())
      .then((data) => { setTickets(Array.isArray(data) ? data : []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const badgeType = (status) => {
    if (status === "urgent")  return "red";
    if (status === "pending") return "gold";
    if (status === "resolved") return "green";
    return "blue";
  };

  return (
    <>
      <PageHeader title="Tickets" subtitle="Quick support ticket overview." />

      {loading && <p style={{ padding: "20px" }}>Loading tickets…</p>}

      <Card>
        {!loading && tickets.length === 0 && (
          <p style={{ padding: "12px", color: "#888" }}>No tickets yet.</p>
        )}
        {tickets.map((ticket) => (
          <div className="ticket" key={ticket.ticket_id}>
            <div>
              <b>{ticket.title}</b>
              <p className="muted">{ticket.message}</p>
            </div>
            <Badge type={badgeType(ticket.status)} style={{ textTransform: "capitalize" }}>
              {ticket.status}
            </Badge>
          </div>
        ))}
      </Card>
    </>
  );
}
