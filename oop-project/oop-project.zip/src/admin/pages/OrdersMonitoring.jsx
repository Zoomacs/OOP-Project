import { useEffect, useState } from "react";
import { PageHeader, Card, StatCard, Badge } from "../components/UI";
import { BACKEND } from "../../api";
import "./OrdersMonitoring.css";

export default function OrdersMonitoring() {
  const [orders, setOrders]   = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`${BACKEND}/api.php?route=admin-orders`)
      .then((r) => r.json())
      .then((data) => { setOrders(Array.isArray(data) ? data : []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const count = (status) =>
    orders.filter((o) => (o.status || "").toLowerCase() === status).length;

  const badgeType = (status) => {
    const s = (status || "").toLowerCase();
    if (s === "cancelled")          return "red";
    if (s === "delivered")          return "green";
    if (s === "out_for_delivery")   return "blue";
    return "gold";
  };

  return (
    <>
      <PageHeader title="Orders Monitoring" subtitle="Track restaurant orders in real time.">
        <button className="btn">Export</button>
      </PageHeader>

      <div className="grid">
        <StatCard title="Preparing"   value={count("preparing")}        badge="Kitchen" badgeClass="gold" />
        <StatCard title="On Delivery" value={count("out_for_delivery")} badge="Riders"  badgeClass="blue" />
        <StatCard title="Delivered"   value={count("delivered")}        badge="Done"    badgeClass="green" />
        <StatCard title="Cancelled"   value={count("cancelled")}        badge="Review"  badgeClass="red" />
      </div>

      <div style={{ marginTop: 20 }}>
        <Card className="table-wrap">
          {loading && <p style={{ padding: "12px" }}>Loading orders…</p>}
          <table>
            <thead>
              <tr><th>Order ID</th><th>Restaurant</th><th>Customer</th><th>Total</th><th>Status</th></tr>
            </thead>
            <tbody>
              {!loading && orders.length === 0 && (
                <tr><td colSpan={5} style={{ textAlign: "center", color: "#888" }}>No orders yet.</td></tr>
              )}
              {orders.map((order) => (
                <tr key={order.order_id}>
                  <td>#{order.order_id}</td>
                  <td>{order.restaurant_name ?? "—"}</td>
                  <td>{order.customer_name   ?? "—"}</td>
                  <td>{order.total_price} EGP</td>
                  <td>
                    <Badge type={badgeType(order.status)} style={{ textTransform: "capitalize" }}>
                      {order.status}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>
    </>
  );
}
