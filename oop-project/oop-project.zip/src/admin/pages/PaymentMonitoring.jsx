import { useEffect, useState } from "react";
import { PageHeader, Card, StatCard, Badge } from "../components/UI";
import { BACKEND } from "../../api";
import "./PaymentMonitoring.css";

export default function PaymentMonitoring() {
  const [orders, setOrders]   = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`${BACKEND}/api.php?route=admin-orders`)
      .then((r) => r.json())
      .then((data) => { setOrders(Array.isArray(data) ? data : []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const total   = orders.reduce((s, o) => s + parseFloat(o.total_price || 0), 0);
  const paid    = orders.filter((o) => (o.payment_status || "").toLowerCase() === "approved").length;
  const pending = orders.filter((o) => !(o.payment_status) || o.payment_status === "pending").length;
  const failed  = orders.filter((o) => (o.payment_status || "").toLowerCase() === "rejected").length;
  const successRate = orders.length ? Math.round((paid / orders.length) * 100) : 0;

  const badgeType = (status) => {
    if (!status || status === "pending") return "gold";
    if (status === "approved") return "green";
    return "red";
  };

  return (
    <>
      <PageHeader title="Payment Monitoring" subtitle="Monitor successful, pending, and failed payments." />

      <div className="grid">
        <StatCard title="Revenue"  value={`${total.toFixed(0)} EGP`} badge="+live"   badgeClass="green" />
        <StatCard title="Success"  value={`${successRate}%`}         badge="Healthy"  badgeClass="green" />
        <StatCard title="Pending"  value={pending}                    badge="Waiting"  badgeClass="gold" />
        <StatCard title="Failed"   value={failed}                     badge="Fix"      badgeClass="red" />
      </div>

      <div style={{ marginTop: 20 }}>
        <Card className="table-wrap">
          {loading && <p style={{ padding: "12px" }}>Loading payments…</p>}
          <table>
            <thead>
              <tr><th>Order ID</th><th>Customer</th><th>Method</th><th>Amount</th><th>Status</th></tr>
            </thead>
            <tbody>
              {!loading && orders.length === 0 && (
                <tr><td colSpan={5} style={{ textAlign: "center", color: "#888" }}>No payments yet.</td></tr>
              )}
              {orders.map((o) => (
                <tr key={o.order_id}>
                  <td>#{o.order_id}</td>
                  <td>{o.customer_name ?? "—"}</td>
                  <td style={{ textTransform: "capitalize" }}>{o.payment_type ?? "—"}</td>
                  <td>{o.total_price} EGP</td>
                  <td>
                    <Badge type={badgeType(o.payment_status)} style={{ textTransform: "capitalize" }}>
                      {o.payment_status ?? "pending"}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>
    </>
  );
}
