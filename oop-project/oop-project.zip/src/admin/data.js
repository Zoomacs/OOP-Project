// src/admin/data.js
// ─── Static data removed — all admin pages now fetch from the backend API ─────
// This file is kept so existing imports don't break; it exports empty arrays.
// Do NOT add static data back here.

export const users        = [];
export const orders       = [];
export const transactions = [];
export const tickets      = [];
