import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import "./OrderHistory.css";
import { BACKEND } from "./api";

const STATUS_NEXT  = { preparing: "ready", ready: "delivered" };
const STATUS_BTN   = { preparing: "Mark as Ready", ready: "Complete Order" };

const OrderCard = ({ image, title, description, time, points, onViewDetails, isOwner, status, onAdvanceStatus }) => (
  <div className="Order-card">
    <div className="card-img">
      {image && <img src={image} alt="logo" />}
    </div>
    <div className="card-content">
      <div className="card-header">
        <h2 className="card-title">{isOwner ? `Order #${title}` : title}</h2>
        {isOwner && <span className={`status-badge ${(status || "").toLowerCase()}`}>{status}</span>}
      </div>
      <div className="card-details">
        <p className="card-description">{description}</p>
        <p className="card-time">{time}</p>
        <div className="card-actions">
          {isOwner ? (
            STATUS_NEXT[(status || "").toLowerCase()] && (
              <button className="details-btn" onClick={onAdvanceStatus}>
                {STATUS_BTN[(status || "").toLowerCase()] || "Update"}
              </button>
            )
          ) : (
            <button className="details-btn" onClick={onViewDetails}>Details</button>
          )}
        </div>
      </div>
    </div>
    {!isOwner && <div className="card-points"><p className="card-points">+{points} Points</p></div>}
  </div>
);

function OrderHistory({ page, isOwner = false }) {
  const navigate = useNavigate();
  const [sortBy, setSortBy]   = useState("date");
  const [orders, setOrders]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState("");

  useEffect(() => { page(isOwner ? "dashboard" : "orderhistory"); }, [page, isOwner]);

  useEffect(() => {
    const customerId   = sessionStorage.getItem("customerId");
    const restaurantId = sessionStorage.getItem("restaurantId");

    const url = isOwner
      ? `${BACKEND}/api.php?route=order-history&restaurant_id=${restaurantId}`
      : `${BACKEND}/api.php?route=order-history&customer_id=${customerId}`;

    fetch(url)
      .then((r) => { if (!r.ok) throw new Error("Server error"); return r.json(); })
      .then((data) => { setOrders(data.data ?? data); setLoading(false); })
      .catch(() => { setError("Could not load orders."); setLoading(false); });
  }, [isOwner]);

  const advanceStatus = async (orderId, currentStatus) => {
    const next = STATUS_NEXT[currentStatus.toLowerCase()];
    if (!next) return;
    try {
      await fetch(`${BACKEND}/api.php?route=update-status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ order_id: orderId, status: next }),
      });
      setOrders((prev) => prev.map((o) => o.order_id === orderId ? { ...o, status: next } : o));
    } catch {
      alert("Failed to update status.");
    }
  };

  const sorted = [...orders].sort((a, b) => {
    if (sortBy === "date") return new Date(b.created_at) - new Date(a.created_at);
    return 0;
  });

  return (
    <div className="oh-page-container">
      <div className="order-place">
        <div className="order-head">
          <div className="order-head-title">
            <h1>{isOwner ? "Restaurant Orders" : "Your Past Orders"}</h1>
            <span className="total-badge">{orders.length} TOTAL ORDERS</span>
          </div>
          <p className="order-head-desc">
            {isOwner
              ? "Monitor, track, and update status logs for live ongoing dining requests across the campus."
              : "Manage and track your recent campus dining activities."}
          </p>
        </div>

        <div className="order-filters">
          <button className={sortBy === "date" ? "active" : ""} onClick={() => setSortBy("date")}>
            Sort by Date
          </button>
        </div>

        {loading && <p style={{ padding: "20px", textAlign: "center" }}>Loading orders…</p>}
        {error   && <p style={{ padding: "20px", color: "#c0392b" }}>{error}</p>}

        <div className="cards-list">
          {!loading && sorted.map((item) => (
            <OrderCard
              key={item.order_id}
              image={item.image_url}
              title={item.order_id}
              description={item.restaurant_name || ""}
              time={new Date(item.created_at).toLocaleString()}
              points={Math.round((item.total_price || 0) * 2)}
              status={item.status}
              isOwner={isOwner}
              onAdvanceStatus={() => advanceStatus(item.order_id, item.status)}
              onViewDetails={() => navigate("/ordertrack", { state: { orderData: item } })}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default OrderHistory;
