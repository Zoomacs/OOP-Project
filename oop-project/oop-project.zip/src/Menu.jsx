import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import "./Menu.css";
import { Search } from "lucide-react";
import { BACKEND } from "./api";

function Menu({ page }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [searchText, setSearchText] = useState("");
  const [menuItems, setMenuItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    page("menu");
  }, [page, id]);

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    setError("");
    fetch(`${BACKEND}/getMenu.php?restaurant_id=${id}`)
      .then((res) => {
        if (!res.ok) throw new Error("Server error " + res.status);
        return res.json();
      })
      .then((data) => {
        // Normalise: backend returns { items: [...] } or a raw array
        const items = Array.isArray(data) ? data : (data.items ?? []);
        setMenuItems(
          items.map((item) => ({
            id:       item.product_id ?? item.id,
            name:     item.product_name ?? item.name,
            desc:     item.description ?? "",
            price:    parseFloat(item.price) || 0,
            rating:   parseInt(item.rating) || 0,
            image:    item.picture ?? item.image_url ?? item.image ?? "",
            quantity: 0,
          }))
        );
        setLoading(false);
      })
      .catch((err) => {
        setError("Could not load menu. " + err.message);
        setLoading(false);
      });
  }, [id]);

  const updateQuantity = (itemId, delta) => {
    setMenuItems((prevItems) =>
      prevItems.map((item) => {
        if (item.id === itemId) {
          const newQuantity = Math.max(0, item.quantity + delta);
          // Dispatch to Cart so it stays in sync
          if (delta > 0 || newQuantity >= 0) {
            window.dispatchEvent(
              new CustomEvent("addToCart", {
                detail: {
                  id:    item.id,
                  title: item.name,
                  price: item.price,
                  image: item.image || null,
                  delta,
                },
              })
            );
          }
          return { ...item, quantity: newQuantity };
        }
        return item;
      })
    );
  };

  const filteredItems = menuItems.filter(
    (item) =>
      item.name.toLowerCase().includes(searchText.toLowerCase()) ||
      item.desc.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <div className="menu-page">
      <div className="menu-header-bar">
        <button className="back-btn" onClick={() => navigate(-1)}>
          &larr;
        </button>
        <div className="menu-search-box">
          <span className="search-icon">
            <Search />
          </span>
          <input
            type="text"
            placeholder="Search menu items..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
          />
        </div>
      </div>

      {loading && <p style={{ padding: "30px", textAlign: "center" }}>Loading menu…</p>}
      {error   && <p style={{ padding: "20px", color: "#c0392b", textAlign: "center" }}>{error}</p>}

      <div className="menu-list">
        {!loading && !error && filteredItems.length === 0 && (
          <p style={{ padding: "20px", textAlign: "center", color: "#888" }}>
            No items found{searchText ? ` for "${searchText}"` : ""}.
          </p>
        )}
        {filteredItems.map((item) => (
          <div className="menu-item-card" key={item.id}>
            {item.image && (
              <img src={item.image} alt={item.name} className="menu-item-image" />
            )}

            <div className="menu-item-details">
              <h3>{item.name}</h3>
              <p className="item-desc">{item.desc}</p>
              <div className="item-price-row">
                <span className="price">EGP {item.price.toFixed(2)}</span>
              </div>
              <div className="item-footer-row">
                <div className="stars">
                  {Array.from({ length: 5 }).map((_, index) => (
                    <span
                      key={index}
                      className={index < item.rating ? "star active" : "star"}
                    >
                      ★
                    </span>
                  ))}
                </div>

                <div className="quantity-controls">
                  {item.quantity > 0 ? (
                    <>
                      <button
                        className="qty-btn"
                        onClick={() => updateQuantity(item.id, -1)}
                      >
                        -
                      </button>
                      <span className="qty-count">{item.quantity}</span>
                      <button
                        className="qty-btn"
                        onClick={() => updateQuantity(item.id, 1)}
                      >
                        +
                      </button>
                    </>
                  ) : (
                    <button
                      className="qty-btn add-btn"
                      onClick={() => updateQuantity(item.id, 1)}
                    >
                      +
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Menu;
