import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Eye, EyeOff } from "lucide-react";
import { apiFetch } from "./api";
import "./Register.css";

function Register({ page }) {
  useEffect(() => {
    if (page) page("register");
  }, [page]);

  const navigate = useNavigate();
  const [tab, settab] = useState("Student");
  const [showpassword, setshowPassword] = useState(false);
  const [showconfirmPassword, setshowConfirmPassword] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const [studentform, setstudentForm] = useState({
    fullName: "",
    ID: "",
    universityEmail: "",
    password: "",
    confirmPassword: "",
  });

  const [staffform, setstaffForm] = useState({
    fullName: "",
    ID: "",
    universityEmail: "",
    department: "",
    password: "",
    confirmPassword: "",
  });

  const handleStudentChange = (event) => {
    setstudentForm({ ...studentform, [event.target.name]: event.target.value });
  };

  const handleStaffChange = (event) => {
    setstaffForm({ ...staffform, [event.target.name]: event.target.value });
  };

  const handleSubmit = async () => {
    setError("");
    setMessage("");

    const form = tab === "Student" ? studentform : staffform;
    const role = tab === "Student" ? "student" : "staff";

    if (!form.fullName || !form.ID || !form.universityEmail || !form.password || !form.confirmPassword) {
      setError("Please fill in all required fields.");
      return;
    }

    if (form.password !== form.confirmPassword) {
      setError("Passwords do not match!");
      return;
    }

    setLoading(true);
    try {
      await apiFetch("api.php?route=register", {
        method: "POST",
        body: JSON.stringify({
          fullName: form.fullName,
          ID: form.ID,
          universityEmail: form.universityEmail,
          password: form.password,
          role,
        }),
      });
      setMessage("Account registered successfully. You can now log in.");
      setTimeout(() => navigate("/"), 800);
    } catch (err) {
      setError(err.message || "Registration failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="reg-wrapper">
      <div className="reg-left">
        <div className="reg-brand">Q-LESS</div>
        <div className="reg-hero">
          <h2 className="reg-hero-title">
            Join the <span className="reg-hero-accent">Campus</span> Dining Revolution.
          </h2>
          <p className="reg-hero-sub">
            Skip the lines and fuel your focus. Create an account to manage your university dining experience with precision and ease.
          </p>
        </div>

        <div className="reg-cards">
          <div className="reg-card">
            <span className="reg-card-icon">⏱</span>
            <h4 className="reg-card-title">Zero Wait Time</h4>
            <p className="reg-card-text">Schedule your meals around your classes and never wait in a queue again.</p>
          </div>
          <div className="reg-card">
            <span className="reg-card-icon">🍴</span>
            <h4 className="reg-card-title">Fresh Updates</h4>
            <p className="reg-card-text">Get real-time daily menu notifications and exclusive campus dining offers.</p>
          </div>
        </div>

        <div className="reg-social-proof">
          <p className="reg-social-text">Joined by 1,000+ students and staff members.</p>
        </div>
      </div>

      <div className="reg-right">
        <div className="reg-form-card">
          <div className="reg-form-header">
            <h2 className="reg-form-title">Create Account</h2>
            <div className="reg-dots">
              <span className="reg-dot reg-dot-active"></span>
              <span className="reg-dot"></span>
              <span className="reg-dot"></span>
            </div>
          </div>

          <div className="reg-tabs">
            {["Student", "Staff"].map((t) => (
              <button
                key={t}
                className={`reg-tab ${tab === t ? "reg-tab-active" : ""}`}
                onClick={() => {
                  settab(t);
                  setshowPassword(false);
                  setshowConfirmPassword(false);
                  setError("");
                  setMessage("");
                }}
              >
                {t}
              </button>
            ))}
          </div>

          <div className="reg-fields">
            {tab === "Student" ? (
              <>
                <div className="reg-field">
                  <label className="reg-field-label">FULL NAME</label>
                  <div className="reg-input-wrap"><span className="reg-input-icon"></span><input className="reg-input" type="text" name="fullName" placeholder="Mostafa Ahmed Mostafa" value={studentform.fullName} onChange={handleStudentChange} /></div>
                </div>
                <div className="reg-field">
                  <label className="reg-field-label">UNIVERSITY ID</label>
                  <div className="reg-input-wrap"><span className="reg-input-icon"></span><input className="reg-input" type="text" name="ID" placeholder="298670" value={studentform.ID} onChange={handleStudentChange} /></div>
                </div>
                <div className="reg-field">
                  <label className="reg-field-label">EMAIL</label>
                  <div className="reg-input-wrap"><span className="reg-input-icon"></span><input className="reg-input" type="email" name="universityEmail" placeholder="mostafa@msa.edu.eg" value={studentform.universityEmail} onChange={handleStudentChange} /></div>
                </div>
                <div className="reg-field">
                  <label className="reg-field-label">PASSWORD</label>
                  <div className="reg-input-wrap"><span className="reg-input-icon"></span><input className="reg-input" type={showpassword ? "text" : "password"} name="password" placeholder="••••••••••••" value={studentform.password} onChange={handleStudentChange} /><button type="button" className="reg-eye" onClick={() => setshowPassword(!showpassword)}>{showpassword ? <EyeOff /> : <Eye />}</button></div>
                </div>
                <div className="reg-field">
                  <label className="reg-field-label">CONFIRM PASSWORD</label>
                  <div className="reg-input-wrap"><span className="reg-input-icon"></span><input className="reg-input" type={showconfirmPassword ? "text" : "password"} name="confirmPassword" placeholder="••••••••••••" value={studentform.confirmPassword} onChange={handleStudentChange} /><button type="button" className="reg-eye" onClick={() => setshowConfirmPassword(!showconfirmPassword)}>{showconfirmPassword ? <EyeOff /> : <Eye />}</button></div>
                </div>
              </>
            ) : (
              <>
                <div className="reg-field">
                  <label className="reg-field-label">FULL NAME</label>
                  <div className="reg-input-wrap"><span className="reg-input-icon"></span><input className="reg-input" type="text" name="fullName" placeholder="Mostafa Mohamed Emad" value={staffform.fullName} onChange={handleStaffChange} /></div>
                </div>
                <div className="reg-field">
                  <label className="reg-field-label">STAFF ID</label>
                  <div className="reg-input-wrap"><span className="reg-input-icon"></span><input className="reg-input" type="text" name="ID" placeholder="23456" value={staffform.ID} onChange={handleStaffChange} /></div>
                </div>
                <div className="reg-field">
                  <label className="reg-field-label">UNIVERSITY EMAIL</label>
                  <div className="reg-input-wrap"><span className="reg-input-icon"></span><input className="reg-input" type="email" name="universityEmail" placeholder="mohanad@university.edu" value={staffform.universityEmail} onChange={handleStaffChange} /></div>
                </div>
                <div className="reg-field">
                  <label className="reg-field-label">DEPARTMENT</label>
                  <div className="reg-input-wrap"><span className="reg-input-icon"></span><input className="reg-input" type="text" name="department" placeholder="Computer Science" value={staffform.department} onChange={handleStaffChange} /></div>
                </div>
                <div className="reg-field">
                  <label className="reg-field-label">PASSWORD</label>
                  <div className="reg-input-wrap"><span className="reg-input-icon"></span><input className="reg-input" type={showpassword ? "text" : "password"} name="password" placeholder="••••••••••••" value={staffform.password} onChange={handleStaffChange} /><button type="button" className="reg-eye" onClick={() => setshowPassword(!showpassword)}>{showpassword ? <EyeOff /> : <Eye />}</button></div>
                </div>
                <div className="reg-field">
                  <label className="reg-field-label">CONFIRM PASSWORD</label>
                  <div className="reg-input-wrap"><span className="reg-input-icon"></span><input className="reg-input" type={showconfirmPassword ? "text" : "password"} name="confirmPassword" placeholder="••••••••••••" value={staffform.confirmPassword} onChange={handleStaffChange} /><button type="button" className="reg-eye" onClick={() => setshowConfirmPassword(!showconfirmPassword)}>{showconfirmPassword ? <EyeOff /> : <Eye />}</button></div>
                </div>
              </>
            )}
          </div>

          {error && <p style={{ color: "#c0392b", marginTop: 10 }}>{error}</p>}
          {message && <p style={{ color: "#27ae60", marginTop: 10 }}>{message}</p>}

          <button className="reg-submit" onClick={handleSubmit} disabled={loading}>
            {loading ? "Creating account…" : "Sign Up"}
          </button>

          <p className="reg-login-link">Already have an account? <a href="/" className="reg-login-a">Log in</a></p>
          <p className="reg-secure"></p>
        </div>
      </div>
    </div>
  );
}

export default Register;
