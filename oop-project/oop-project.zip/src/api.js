// src/api.js
// Single source of truth for the XAMPP backend URL.
// Your htdocs folder is: C:\xampp\htdocs\oop-projectx\oop-project\backend\
export const BACKEND = "http://localhost/oop-projectx/oop-project/backend";

export async function apiFetch(endpoint, options = {}) {
  const url = endpoint.startsWith("http") ? endpoint : `${BACKEND}/${endpoint}`;
  const res = await fetch(url, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });

  let data = null;
  try {
    data = await res.json();
  } catch {
    data = {};
  }

  if (!res.ok) throw new Error(data.message || data.error || "Request failed");
  return data;
}
