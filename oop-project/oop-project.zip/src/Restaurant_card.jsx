import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Restaurant_card.css";
import { Search } from "lucide-react";
import { BACKEND } from "./api";

function RestaurantList() {
  const [restaurants, setRestaurants]     = useState([]);
  const [loading, setLoading]             = useState(true);
  const [error, setError]                 = useState("");
  const [searchText, setSearchText]       = useState("");
  const [selectedFilter, setSelectedFilter] = useState("All");

  const filters = ["All", "Fast Food", "Pizza", "Fool", "Healthy", "Drinks", "Desserts"];

  useEffect(() => {
    fetch(`${BACKEND}/getRestaurants.php`)
      .then((res) => {
        if (!res.ok) throw new Error("Server error " + res.status);
        return res.json();
      })
      .then((data) => { setRestaurants(data); setLoading(false); })
      .catch((err) => { setError("Could not load restaurants. Is XAMPP running? " + err.message); setLoading(false); });
  }, []);

  const filteredRestaurants = restaurants.filter((r) => {
    const name = r.name.toLowerCase();
    const desc = (r.description || "").toLowerCase();
    const matchesSearch = name.includes(searchText.toLowerCase()) || desc.includes(searchText.toLowerCase());
    const matchesFilter = selectedFilter === "All" || desc.includes(selectedFilter.toLowerCase());
    return matchesSearch && matchesFilter;
  });

  return (
    <>
      <div className="restaurant-tools">
        <div className="restaurant-search-box">
          <span className="search-icon"><Search /></span>
          <input
            type="text"
            placeholder="Search restaurants..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
          />
        </div>
      </div>

      <div className="quick-filters">
        {filters.map((filter) => (
          <button
            key={filter}
            className={`filter-btn ${selectedFilter === filter ? "active" : ""}`}
            onClick={() => setSelectedFilter(filter)}
          >
            {filter}
          </button>
        ))}
      </div>

      {loading && <p style={{ padding: "30px", textAlign: "center" }}>Loading restaurants…</p>}
      {error   && <p style={{ padding: "20px", color: "#c0392b", textAlign: "center" }}>{error}</p>}

      <div className="restaurant-list">
        {!loading && !error && (
          filteredRestaurants.length > 0
            ? filteredRestaurants.map((r) => <RestaurantCard key={r.id} restaurant={r} />)
            : <p className="no-restaurants">No restaurants found.</p>
        )}
      </div>
    </>
  );
}

function RestaurantCard({ restaurant }) {
  const navigate = useNavigate();
  return (
    <div className="restaurant-card">
      <div className="restaurant-content">
        <div className="restaurant-top-row">
          <div className="restaurant-logo">
            <img src={restaurant.imageUrl} alt={`${restaurant.name} logo`} />
          </div>
          <span className={`status-badge ${restaurant.isOpen ? "open" : "closed"}`}>
            {restaurant.isOpen ? "Open now" : "Closed"}
          </span>
        </div>

        <h2>{restaurant.name}</h2>
        <p className="restaurant-category">{restaurant.description}</p>

        <div className="restaurant-info">
          <span className="rating">⭐ {restaurant.rating}</span>
          <span className="reviews">({restaurant.reviews})</span>
          <span className="separator">|</span>
          <span>🕒 {restaurant.time}</span>
        </div>

        <div className="restaurant-services">
          <span>🛍 Pickup only</span>
          {restaurant.staffDelivery && <span>🚶 Staff delivery</span>}
        </div>

        <button className="view-menu-btn" onClick={() => navigate(`/restaurant/${restaurant.id}`)}>
          View Menu
        </button>
      </div>
    </div>
  );
}

export default RestaurantList;
