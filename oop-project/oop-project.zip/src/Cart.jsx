import { useState, useEffect } from "react";
import "./Cart.css";
import { useNavigate } from "react-router-dom";
import { X, ShoppingBag } from "lucide-react";

function Cart({ page, display }) {
  const navigate = useNavigate();

  // Start empty — items are added via the addToCart custom event
  const [items, setItem] = useState([]);

  // Listen for 'addToCart' events from Menu and Home components
  useEffect(() => {
    const handleAddToCart = (event) => {
      const newItem = event.detail;
      const delta = newItem.delta ?? 1;

      setItem((prevItems) => {
        const existingItem = prevItems.find((item) => item.id === newItem.id);

        if (existingItem) {
          // Adjust quantity; remove if it drops to 0
          const updated = prevItems.map((item) =>
            item.id === newItem.id
              ? { ...item, quantity: Math.max(0, item.quantity + delta) }
              : item
          );
          return updated.filter((item) => item.quantity > 0);
        } else {
          if (delta <= 0) return prevItems;
          return [...prevItems, { ...newItem, quantity: 1 }];
        }
      });
    };

    window.addEventListener("addToCart", handleAddToCart);
    return () => window.removeEventListener("addToCart", handleAddToCart);
  }, []);

  function setItemQuantity(targetId, sign) {
    setItem((prvQ) =>
      prvQ
        .map((item) => {
          if (item.id === targetId) {
            const next = sign === "+" ? item.quantity + 1 : item.quantity - 1;
            return { ...item, quantity: next };
          }
          return item;
        })
        .filter((item) => item.quantity > 0)
    );
  }

  function deleteItem(targetId) {
    setItem((prv) => prv.filter((item) => item.id !== targetId));
  }

  let total = 0;
  items.forEach((item) => (total += item.price * item.quantity));

  return (
    <div className={`cart-bar ${display}`}>
      <div className="cart-header">
        <h1 className="cart-title">Cart</h1>
      </div>

      <div className="cart-items-container">
        {items.length > 0 ? (
          items.map((item) => (
            <div className="cart-list" key={item.id}>
              <button
                className="delete-item"
                onClick={() => deleteItem(item.id)}
              >
                <X size={16} />
              </button>
              <div className="cart-item">
                {item.image ? (
                  <img src={item.image} alt={item.title} className="item-img" />
                ) : (
                  <div className="item-img-placeholder">
                    <ShoppingBag size={24} />
                  </div>
                )}
                <div className="item-info">
                  <h3>{item.title}</h3>
                  <div className="item-price">
                    <p>{item.price} EGP</p>
                    <div className="quantity">
                      <button
                        className="quantity-btn"
                        onClick={() => setItemQuantity(item.id, "-")}
                      >
                        -
                      </button>
                      <p>{item.quantity}</p>
                      <button
                        className="quantity-btn"
                        onClick={() => setItemQuantity(item.id, "+")}
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="cart-empty">
            <ShoppingBag size={48} />
            <p>Your cart is empty</p>
          </div>
        )}
      </div>

      <div className="cart-footer">
        <div className="total-row">
          <p>Subtotal</p>
          <p>{total} EGP</p>
        </div>
        <div className="total-row">
          <p>Discount</p>
          <p>0%</p>
        </div>
        <div className="total-row grand-total">
          <h2>Total</h2>
          <h2>{total} EGP</h2>
        </div>
        <button
          className="checkout"
          onClick={() => navigate("/checkout")}
          disabled={items.length === 0}
        >
          Checkout
        </button>
      </div>
    </div>
  );
}

export default Cart;
