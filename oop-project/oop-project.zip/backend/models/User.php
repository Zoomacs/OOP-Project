<?php
require_once __DIR__ . '/../config/Database.php';

class User {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function findByEmail($email) {
        $stmt = $this->db->prepare("
            SELECT u.*, c.customer_type, c.phone, c.students_points
            FROM users u
            LEFT JOIN customers c ON u.user_id = c.user_id
            WHERE u.email = ?
        ");
        $stmt->execute([$email]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function createUser($name, $email, $password, $type) {
        $stmt = $this->db->prepare("
            INSERT INTO users (name, email, password, type)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$name, $email, $password, $type]);
        return $this->db->lastInsertId();
    }

    public function createCustomer($user_id, $phone, $customer_type) {
        $stmt = $this->db->prepare("
            INSERT INTO customers (user_id, phone, customer_type)
            VALUES (?, ?, ?)
        ");
        $stmt->execute([$user_id, $phone, $customer_type]);
        return $this->db->lastInsertId();
    }
}
?>